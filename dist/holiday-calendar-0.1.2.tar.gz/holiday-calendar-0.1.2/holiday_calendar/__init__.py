# python3.7
# encoding: utf-8
"""
@author: Chenjin.Qian
@email:  chenjin.qian@xquant.com
@file:   __init__.py
@time:   2020-06-30 11:09
"""
from .get_data import GetHoliday


__version__ = "0.1.2"
__all__ = [
    "GetHoliday",
]
