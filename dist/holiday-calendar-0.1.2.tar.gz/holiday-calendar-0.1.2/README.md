# 中国节假日

判断某年某月某一天是不是工作日/节假日。

## 安装

```shell
pip install holiday-calendar
```
